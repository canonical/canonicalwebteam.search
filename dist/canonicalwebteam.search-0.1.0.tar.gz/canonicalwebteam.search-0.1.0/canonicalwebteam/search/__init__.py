# flake8: noqa

from canonicalwebteam.search.views import build_search_view, NoAPIKeyError
